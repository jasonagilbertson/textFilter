﻿// ************************************************************************************
// Assembly: TextFilter
// File: IMainViewModel.cs
// Created: 12/24/2016
// Modified: 2/11/2017
// Copyright (c) 2017 jason gilbertson
//
// ************************************************************************************

namespace TextFilter
{
    public interface IMainViewModel
    {
        event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;
    }
}