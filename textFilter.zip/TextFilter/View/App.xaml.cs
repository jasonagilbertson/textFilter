﻿// ************************************************************************************
// Assembly: TextFilter
// File: App.xaml.cs
// Created: 9/6/2016
// Modified: 2/11/2017
// Copyright (c) 2017 jason gilbertson
//
// ************************************************************************************

using System.Windows;

namespace TextFilter
{
    public partial class App : Application
    {
    }
}